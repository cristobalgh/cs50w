# Project 0

Web Programming with Python and JavaScript

For this project I chose to do a personal web page template.

The project is composed of 4 pages, the first is a general page, and the other 3 pages of more informations: a cv page, an hobby page and a contact page.

I put a nice big portrait picture in front of the page together with name and a list of the pages available in the website.
For the list of pages i uses the btn-grp component of bootstrap to make the list look nice.

The hobbies page consists of am unordered list of hobbies.
The cv page has several different containers together with a table of skills and percentage value.
The contacts page containes a list of contacts. 

Finally all three pages contain a footer with links to all pages to allow to go through every page in the website. The footer is organized in columns using the bootstrap grid component.

I used sass to assign different colors to various divs and to do assign the media query to all the pages.

I used the media query to change the space occupied by the central div when the page shrinks, going from 80% to 100%.