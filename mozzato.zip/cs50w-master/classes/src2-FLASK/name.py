name = input()
print(f"hello, {name}!")
