THis is the cs50w folder 
